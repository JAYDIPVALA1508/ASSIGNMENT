// Write a C++ program that calculates the factorial of a number using recursion.
#include<iostream>
using namespace std;
int Factorial(int n)
{
    if(n!=0)
    {
        return n * Factorial(n-1);
    }
    else
    {
        return 1;
    }
}
int main()
{
    int num;
    cout<<"Enter the value of num = ";
    cin>>num;
    int result = Factorial(num);
    cout<<"The factorial of "<<num<<" is = "<<result<<endl;
    return 0;
}