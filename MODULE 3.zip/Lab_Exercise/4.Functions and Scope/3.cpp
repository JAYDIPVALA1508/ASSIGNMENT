// Write a program that demonstrates the difference between local and global
// variables in C++. Use functions to show scope.

//Global Scope is declared outside of any function
//Local Scope is declared inside a function
#include<iostream>
using namespace std;
int result;//Global variable
int Multi(int n1, int n2)
{
     result = n1*n2;
     return result; //Local variable result is used here
}
int main()
{
    int num1, num2;//Local variables
    cout<<"Enter the value of num1 = ";
    cin>>num1;
    cout<<"Enter the value of num2 = ";
    cin>>num2;
    result = Multi(num1,num2);
    cout<<"The multiplication of "<<num1<<" * "<<num2<<" is : "<<result<<endl;
    return 0;
}