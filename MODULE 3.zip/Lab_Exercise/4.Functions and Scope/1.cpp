// Simple Calculator Using Functions
// o Write a C++ program that defines functions for basic arithmetic operations (add,
// subtract, multiply, divide). The main function should call these based on user input.
#include<iostream>
using namespace std;
int Addition(int n1, int n2)
{
    return n1 + n2;
}
int Subtraction(int n1, int n2)
{
    return n1 - n2;
}
int Multiplication(int n1, int n2)
{
    return n1 * n2;
}
float Division(int n1, int n2)
{
    if(n2 == 0)
    {
        cout<<"Error dividing by zero!"<<endl;
        return 0;
    }
    else
    {
        return (float)n1/(float)n2;
    }
}
int Remainder(int n1, int n2)
{
    return n1 % n2;
}
int main()
{
    int num1,num2,choice,result;
    cout<<"Enter the value of num1 = ";
    cin>>num1;
    cout<<"Enter the value of num2 = ";
    cin>>num2;
    cout<<"1. Addition"<<endl;
    cout<<"2. Subtraction"<<endl;
    cout<<"3. Multiplication"<<endl;
    cout<<"4. Division"<<endl;
    cout<<"5. Remainder"<<endl;
    cout<<"Enter your choice : ";
    cin>>choice;

    switch(choice)
    {
        case 1:
            result = Addition(num1,num2);
            cout<<"The addition of "<<num1<<" + "<<num2<<" is : "<<result<<endl;
            break;
        case 2:
            result = Subtraction(num1,num2);
            cout<<"The subtraction of "<<num1<<" - "<<num2<<" is : "<<result<<endl;
            break;
        case 3:
            result = Multiplication(num1,num2);
            cout<<"The multiplication of "<<num1<<" * "<<num2<<" is : "<<result<<endl;
            break;
        case 4:
            result = Division(num1,num2);
            if(result != 0) // Only print if division was successful
                cout<<"The division of "<<num1<<" / "<<num2<<" is : "<<result<<endl;
            break;
        case 5:
            result = Remainder(num1,num2);
            cout<<"The remainder of "<<num1<<" % "<<num2<<" is : "<<result<<endl;
            break;
        default:
            cout<<"Invalid choice!"<<endl;
            break;
          return 0;           
    }
}