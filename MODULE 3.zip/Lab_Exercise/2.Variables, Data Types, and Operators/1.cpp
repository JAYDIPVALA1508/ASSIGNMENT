// Write a C++ program that demonstrates the use of variables and constants. Create
// // variables of different data types and perform operations on them.
#include<iostream>
using namespace std;
int main()
{
    int a = 10;
    int const b = 20;
    float f1 = 20.45,f2 = 30.55;
    string str1 = "Hello", str2 = "World";

    cout<<"The addition of "<<a<<" and "<<b<<" is = "<<a+b<<endl;

    cout<<"The division of "<<f1<<" and "<<f2<<" is = "<<f1/f2<<endl;

    cout<<"The full value of string = "<<str1+str2<<endl;
    return 0;
}