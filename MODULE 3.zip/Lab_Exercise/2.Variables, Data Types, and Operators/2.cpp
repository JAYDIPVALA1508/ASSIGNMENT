// Write a C++ program that performs both implicit and explicit type conversions and
// prints the results.
#include <iostream>
using namespace std;
int main()
{
    //Implicit Type Conversion
    int a = 10;
    double b = a;
    cout<<"Value of a = "<<a<<endl;
    cout<<"Value of b after implicit conversion = "<<b<<endl;

    double c = 20.567;
    int d = c;
    cout<<"Value of c= "<<c<<endl;
    cout<<"Integer value of d after implicit conversion = "<<d<<endl;
    cout<<"\n";
    //Explicit Type Conversion
    double e = 15.75;
    int i = (int)e;
    cout<<"Value of e = "<<e<<endl;
    cout<<"Integer value of i after explicit conversion = "<<i<<endl;
    return 0; 
}