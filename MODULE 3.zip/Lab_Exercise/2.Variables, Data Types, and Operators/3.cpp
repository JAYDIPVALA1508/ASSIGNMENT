// Write a C++ program that demonstrates arithmetic, relational, logical, and bitwise
// operators. Perform operations using each type of operator and display the results.
#include <iostream>
using namespace std;
int main()
{
    int n1,n2;
    cout<<"Enter the value of n1 = ";
    cin>>n1;
    cout<<"Enter the value of n2 = ";
    cin>>n2;

    // Arithmetic Operators
    cout << "Arithmetic Operations:" << endl;
    cout << "Addition (n1 + n2): " << n1 + n2 << endl;
    cout << "Subtraction (n1 - n2): " << n1 - n2 << endl;
    cout << "Multiplication (n1 * n2): " << n1 * n2 << endl;
    cout << "Division (n1 / n2): " << (float)n1 / (float)n2 << endl;
    cout << "Modulus (n1 % n2): " << n1 % n2 << endl;
    cout << "\n";

    // Relational Operators
    cout << "Relational Operations:" << endl;
    cout << "n1 == n2: " << (n1 == n2) << endl;
    cout << "n1 != n2: " << (n1 != n2) << endl;
    cout << "n1 > n2: " << (n1 > n2) << endl;
    cout << "n1 < n2: " << (n1 < n2) << endl;
    cout << "n1 >= n2: " << (n1 >= n2) << endl;
    cout << "n1 <= n2: " << (n1 <= n2) << endl;
    cout << "\n";

    // Logical Operators
    cout << "Logical Operations:" << endl;
    cout << "(n1 > n2) && (n1 < 100): " << ((n1 > n2) && (n1 < 100)) << endl;
    cout << "(n1 < n2) || (n1 > 0): " << ((n1 < n2) || (n1 > 0)) << endl;
    cout << "!(n1 == n2): " << !(n1 == n2) << endl;
    cout << "\n";

    // Bitwise Operators
    cout << "Bitwise Operations:" << endl;
    cout << "n1 & n2: " << (n1 & n2) << endl;
    cout << "n1 | n2: " << (n1 | n2) << endl;
    cout << "n1 ^ n2: " << (n1 ^ n2) << endl;
    cout << "~n1: " << (~n1) << endl;
    cout << "n1 << 1: " << (n1 << 1) << endl;
    cout << "n1 >> 1: " << (n1 >> 1) << endl;
    cout << "\n";
    return 0;
}