// Write a C++ program to perform matrix addition on two 2x2 matrices.
#include<iostream>
using namespace std;
int main()
{
    cout<<"Elements of Matrix A = "<<endl;
    int a[2][2], b[2][2], sum[2][2], i, j;
    
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
        cout<<"Enter the value of a["<<i<<"]["<<j<<"] = ";
        cin>>a[i][j];
        }
    }
    cout<<"Elements of Matrix B = "<<endl;
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
        cout<<"Enter the value of b["<<i<<"]["<<j<<"] = ";
        cin>>b[i][j];
        }
    }

    cout<<"\n";
    cout<<"Matrix A = "<<endl;
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<"\n";
    }
    cout<<"Matrix B = "<<endl;
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            cout<<b[i][j]<<" ";
        }
        cout<<"\n";
    }
    cout<<"Sum of Matrix A and B = "<<endl;
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
                sum[i][j] = a[i][j] + b[i][j];
        }
    }
    cout<<"Matrix after addition = "<<endl;
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            cout<<sum[i][j]<<" ";
        }
 
    }
    return 0;
}