// Write a C++ program that accepts an array of integers, calculates the sum and
// average, and displays the results.
#include<iostream>
using namespace std;
int main()
{
    int arr[100], size, i, sum = 0;
    cout<<"Enter the value of size = ";
    cin>>size;

    for(i=0;i<size;i++)
    {
    cout<<"Enter the elements of an arr["<<i<<"] = ";
    cin>>arr[i];
    }

    cout<<"Array = ";
    for(i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
        sum = sum + arr[i];
    } 

    float average = (float)sum/(float)size;
    cout<<"\nSum of the array elements = "<<sum<<endl;
    cout<<"Average of the array elements = "<<average<<endl;
    return 0;
}