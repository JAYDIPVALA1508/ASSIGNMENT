// Write a program that asks for two numbers and displays their sum. Ensure this is
// done after setting up the IDE (like Dev C++ or CodeBlocks).
#include<iostream>
using namespace std;
int main()
{
    int n1,n2;
    cout<<"Enter the value of n1 = ";
    cin>>n1;
    cout<<"Enter the value of n2 = ";
    cin>>n2;

    cout<<"The sum of "<<n1<<" and "<<n2<<" is = "<<n1+n2<<endl;
    return 0;
}