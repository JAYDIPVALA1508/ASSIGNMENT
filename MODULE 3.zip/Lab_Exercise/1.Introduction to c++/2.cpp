// Write a C++ program that accepts user input for their name and age and then
// displays a personalized greeting.
#include <iostream>
using namespace std;
int main()
{
    int age;
    string name;

    cout<<"Enter your name = ";
    cin>>name;
    cout<<"Enter your age = ";
    cin>>age;

    cout<<"Hello "<<name<<", How are you?"<<endl;
    return 0;
}
