//Write a simple C++ program to display "Hello, World!".
#include <iostream>
using namespace std;
int main()
{
    cout<<"Hello World!"<<endl;
    return 0;
}