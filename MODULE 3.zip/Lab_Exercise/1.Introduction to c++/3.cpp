// Write two small programs: one using Procedural Programming (POP) to calculate the
// area of a rectangle, and another using Object-Oriented Programming (OOP) with a
// class and object for the same task.

//Using Procedural Programming (POP) to calculate the area of a rectangle
#include<stdio.h>
int main()
{
    int length,breadth,area;
    printf("Enter the value of length = ");
    scanf("%d",&length);

    printf("Enter the value of breadth = ");
    scanf("%d",&breadth);

    area = length * breadth;
    printf("\nArea of rectangle = %d",area);
    return 0;
}

//Using Object-Oriented Programming (OOP) to calculate the area of a rectangle
#include <iostream>
using namespace std;
class Rectangle 
{
    public:
        Rectangle(int l, int b)
        {
            cout<<"The area of rectangle is = "<<l*b<<endl;
        }
};

int main()
{
    int length, breadth;
    cout<<"Enter the value of length = ";
    cin>>length;
    cout<<"Enter the value of breath = ";
    cin>>breadth;
    Rectangle(length,breadth);
    return 0;
}