// Create a class BankAccount with data members like balance and member functions
// like deposit and withdraw. Implement encapsulation by keeping the data members
// private.
#include<iostream>
using namespace std;
class Bank_account
{
    private:
        double balance;

    public:
        Bank_account(double initial_balance)
        {
            if(initial_balance>=0)
            {
                balance = initial_balance;
            }
            else
            {
                cout << "Invalid initial balance cannot be negative"<<endl;
                balance = 0;
            }
        }

        //Deposit function
        void deposit(double amount)
        {
            if(amount>0)
            {
                balance = balance + amount;
                cout<<"Amount "<<amount<<" deposited successfully."<<endl;
            }
            else
            {
                cout<<"Invalid deposit amount"<<endl;
            }
        }

        //Withraw function
        void withdraw(double amount)
        {
            if (amount>0 && amount<=balance)
            {
               balance = balance - amount;
               cout<<"Amount "<<amount<<" withdrawn successfully."<<endl;
            }
            else if(amount > balance)
            {
                cout<<"Insufficient balance for withdrawal"<<endl;
            }
            else
            {
                cout<<"Invalid withdrawal amount"<<endl;
            }
        }

            //Check balance
            double check_balance()
            {
                return balance;
            }
            
};
int main()
{
    // Bank_account account();
    double initial_bal,deposit_amt,withdraw_amt;
    cout<<"Enter initial balance: ";
    cin>>initial_bal;
    Bank_account account(initial_bal);

    cout<<"Enter amount to deposit: ";
    cin>>deposit_amt;
    account.deposit(deposit_amt);

    cout<<"Current balance: "<<account.check_balance()<<endl;

    cout<<"Enter amount to withdraw: ";
    cin>>withdraw_amt;
    account.withdraw(withdraw_amt);

    cout<<"Current balance: "<<account.check_balance()<<endl;
    return 0;
}