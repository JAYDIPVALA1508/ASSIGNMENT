// Write a C++ program that defines a class Calculator with functions for addition,
// subtraction, multiplication, and division. Create objects to use these functions.
#include <iostream>
using namespace std;

class Calculator {
public:
    int Addition(int n1, int n2) {
        return n1 + n2;
    }

    int Subtraction(int n1, int n2) {
        return n1 - n2;
    }

    int Multiplication(int n1, int n2) {
        return n1 * n2;
    }

    float Division(int n1, int n2) {
        if (n2 == 0) {
            cout << "Error: Division by zero!" << endl;
            return 0;
        }
        return (float)(n1) / (float)n2;
    }

    int Remainder(int n1, int n2) {
        if (n2 == 0) {
            cout << "Error: Division by zero for remainder!" << endl;
            return 0;
        }
        return n1 % n2;
    }
};

int main() {
    int num1, num2, choice,result;

    Calculator calc;

    cout << "Enter the value of num1 = ";
    cin >> num1;
    cout << "Enter the value of num2 = ";
    cin >> num2;

    cout << "1. Addition" << endl;
    cout << "2. Subtraction" << endl;
    cout << "3. Multiplication" << endl;
    cout << "4. Division" << endl;
    cout << "5. Remainder" << endl;
    cout << "Enter your choice = ";
    cin >> choice;

    switch (choice) {
        case 1:
            cout << "The addition of "<<num1<<" + "<<num2<<" is = "<< calc.Addition(num1, num2)<<endl;
            break;
        case 2:
            cout << "The subtraction of "<<num1<<" - "<<num2<<" is = "<< calc.Subtraction(num1, num2)<<endl;
            break;
        case 3:
            cout << "The Multiplication of "<<num1<<" * "<<num2<<" is = "<< calc.Multiplication(num1, num2)<<endl;
            break;
        case 4:
            result = calc.Division(num1, num2);
            if (num2 != 0)
            cout << "The Division of "<<num1<<" / "<<num2<<" is = "<< calc.Division(num1, num2)<<endl;
            break;
        case 5:
            if (num2 != 0)
            cout << "The Remainder of "<<num1<<" % "<<num2<<" is = "<< calc.Remainder(num1, num2)<<endl;
            break;
        default:
            cout << "Invalid choice" << endl;
    }

    return 0;
}