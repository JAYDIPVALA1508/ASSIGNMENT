// o Write a program that implements inheritance using a base class Person and derived
// classes Student and Teacher. Demonstrate reusability through inheritance.
#include <iostream>
using namespace std;
class Person
{
    private:
        string name;
        int age;

    public:
    void Person_details(string n, int a)
    {
        name = n;
        age = a;
    }

    void display_person()
    {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl; 
    }
};

class Student : public Person
{
    private:
    int S_id;
    string S_name;

    public:
    void Student_details(int id, string name)
    {
        S_id = id;
        S_name = name;
    }

    void display_Student()
    {
        cout << "Student ID: " << S_id << endl;
        cout << "Student Name: " << S_name << endl;
    }
};

class Teacher : public Person
{
    private:
    int T_id;
    string T_name;

    public:
    void Teacher_details(int id, string name)
    {
        T_id = id;
        T_name = name;
    }
    void display_Teacher()
    {
        cout << "Teacher ID: " << T_id << endl;
        cout << "Teacher Name: " << T_name << endl;
    }
};

int main()
{
    // cout << "Person" << endl;
    // cout << "-------------------" << endl;
    // Person p;
    // p.Person_details("Rudra", 30);
    // p.display_person();
    // cout<<"\n";

    cout << "Student" << endl;
    cout << "-------------------" << endl;
    Student s;
    s.Student_details(101,"Nihar");
    s.display_Student();
    cout<<"\n";

    cout << "Teacher" << endl;
    cout << "-------------------" << endl;
    Teacher t;
    t.Teacher_details(101,"Rohit");
    t.display_Teacher();
    cout<<"\n";
    return 0;
}