// Write a C++ program that asks the user to guess a number between 1 and 100. The
// program should provide hints if the guess is too high or too low. Use loops to allow
// the user multiple attempts.

#include <iostream>
using namespace std;
int main()
{
    int secret_number = 42;
    int user_guess;
    int attempts = 0;
    const int max_attempts = 5; 
    cout << "Welcome to the Number Guessing Game!" << endl;
    cout << "Try to guess the number between 1 and 100." << endl;

    while (attempts < max_attempts) {
        cout << "Enter your guess: ";
        cin >> user_guess;

        if (user_guess < 1 || user_guess > 100) {
            cout << "Please enter a number between 1 and 100." << endl;
            continue; 
        }

        attempts++;

        if (user_guess == secret_number) {
            cout << "Congratulations! You've guessed the number in " << attempts << " attempts!" << endl;
            break;
        } else if (user_guess < secret_number) {
            cout << "Too low! Try again." << endl;
        } else {
            cout << "Too high! Try again." << endl;
        }

        if (attempts == max_attempts) {
            cout << "Sorry, you've used all your attempts. The secret number was " << secret_number << "." << endl;
        }
    }
    return 0;
}