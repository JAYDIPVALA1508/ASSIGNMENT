// Write a C++ program that takes a student’s marks as input and calculates the grade
// based on if-else conditions.
#include <iostream>
using namespace std;
int main()
{
    int marks;
    cout<<"Enter the value of marks = ";
    cin>>marks;
    char grade;

    if(marks>=90)
    {
        grade = 'A';
    }
    else if(marks>=70)
    {
        grade = 'B';
    }
    else if(marks>=50)
    {
        grade = 'C';
    }
    else
    {
        grade = 'D';
    }
    cout<<"The grade is: "<<grade<<endl;
     return 0;
}
