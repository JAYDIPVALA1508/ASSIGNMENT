// Write a program that prints a right-angled triangle using stars(*) with a nested loop
#include<iostream>
using namespace std;
int main()
{
    int row,i,j;
    cout<<"Enter the value of row count = ";
    cin>>row;

    for(i=1;i<=row;i++)
    {
        for(j=1;j<=i;j++)
        {
            cout<<"* ";
        }
        cout<<"\n";
    }
    return 0;
}